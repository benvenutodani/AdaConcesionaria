package org.concesionaria.concesionaria.repository;

import org.concesionaria.concesionaria.entity.Contrato;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContratoRepository extends JpaRepository <Contrato, Integer>{
}
