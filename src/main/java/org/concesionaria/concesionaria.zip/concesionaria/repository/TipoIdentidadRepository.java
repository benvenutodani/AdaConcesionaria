package org.concesionaria.concesionaria.repository;

import org.concesionaria.concesionaria.entity.MetodoPago;
import org.concesionaria.concesionaria.entity.TipoIdentidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoIdentidadRepository extends JpaRepository<TipoIdentidad, Integer> {


}
