package org.concesionaria.concesionaria.repository;

import org.concesionaria.concesionaria.entity.MetodoPago;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetodoPagoRepository extends JpaRepository<MetodoPago, Integer> {

}
