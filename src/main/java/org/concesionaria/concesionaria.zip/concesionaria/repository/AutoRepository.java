package org.concesionaria.concesionaria.repository;

import org.concesionaria.concesionaria.entity.Auto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AutoRepository extends JpaRepository<Auto,String> {
}
